from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.debug = True
app.secret_key = 'DFRVGTUY*PFPGI{"|BHSADVF(G)*IPAU{ODPFKL'


@app.route('/training/<profession>')
def training(profession):
    if 'инженер' in profession or 'строитель' in profession:
        return render_template('training.html', profession=1)
    return render_template('training.html', profession=0)


@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/list_prof/<status>')
def list_prof(status):
    if status == 'ol':
        status = 1
    else:
        status = 0
    return render_template('list.html', status=status)


class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    captain_id = StringField('ID капитана', validators=[DataRequired()])
    captain_pass = StringField('Пароль капитана', validators=[DataRequired()])
    remember_me = BooleanField('Запомнить меня')
    submit = SubmitField('Войти')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return 'success'
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/distribution')
def dist():
    return render_template('dist.html', users=['1 пассажир',
                                               '2 пассажир',
                                               '3 пассажир'])


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1', debug=True)
